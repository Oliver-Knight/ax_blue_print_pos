enum ReceiptTextSizeType { small, medium, large, extraLarge }
