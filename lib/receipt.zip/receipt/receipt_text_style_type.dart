enum ReceiptTextStyleType { normal, bold }
