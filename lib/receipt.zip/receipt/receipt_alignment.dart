enum ReceiptAlignment { left, center, right }
